<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=dbs.cz0hcotmgf7f.ap-south-1.rds.amazonaws.com;port=3306;dbname=dbs',
    'username' => 'dbs',
    'password' => 'dbs_hack2hire',
    'charset' => 'utf8',
    'tablePrefix' =>'dbs'
];
