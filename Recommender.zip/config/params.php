<?php

return [
    'adminEmail' => 'admin@example.com',
    'rating' => 4.8,
    'distance'=>5
];
